package java.txt;

import java.util.Date;

public class SimpleDateFormat {

	public SimpleDateFormat(String string) {
		// TODO Auto-generated constructor stub
	}

	public String format(Date data) {
		// TODO Auto-generated method stub
		return null;
	}

}
